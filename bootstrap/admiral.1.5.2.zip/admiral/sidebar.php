<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package Admiral
 */

// Display Main Sidebar.
get_sidebar( 'main' );

// Display Small Sidebar.
get_sidebar( 'small' );
